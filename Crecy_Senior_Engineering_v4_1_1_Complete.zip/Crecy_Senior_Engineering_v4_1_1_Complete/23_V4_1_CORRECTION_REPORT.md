# 23 — Crecy v4.1 Correction Report

## Closed defects

1. Files 12–17 are distributed as normal files; no GitHub Actions materialization is required.
2. Persistence added for idempotency, Stripe webhook deduplication, invitations, messaging, announcements, notification delivery, document delivery/acknowledgement, upload quarantine/scanning, privacy requests, owner approval history, localized pricing, usage, and invoices.
3. `work_orders.version` and `maintenance_requests.public_reference/version` now match command contracts.
4. Owner statements support immutable correction versions and PDF/CSV document-version links.
5. Required P0 financial, access, messaging, announcement, billing, privacy, remittance, document and owner-approval commands are explicit.
6. Membership effective dates are enforced in property access. Property-scoped roles no longer gain organization-wide people/finance/owner/vendor access through broad permission checks.
7. Owner/vendor screens use sanitized projections; full resident lease, payment and maintenance rows are not granted to those relationships.
8. Cross-organization composite integrity constraints cover core P0 relationships.
9. Product name is locked as Crecy; only final logo artwork remains open.

## Development gate

Phase 1 foundation may begin after SQL syntax/migration decomposition review and adversarial RLS tests are scaffolded. Payments, resident production data and owner portal production access remain blocked until the associated tests and professional production evidence pass.
