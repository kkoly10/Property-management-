# Apartment Rental Platform — Senior Engineering Edition v2

This edition incorporates the approved global country-profile architecture and the United States/Canada/Mexico early commercial launch strategy.

Read in this order:

1. `00_READ_ME_FIRST.md`
2. `07_FOUNDER_DECISION_REGISTER.md`
3. `08_GLOBAL_COUNTRY_PROFILE_AND_PAYMENT_ORCHESTRATION_SPEC.md`
4. `01_PRODUCT_AND_SYSTEM_ARCHITECTURE_SPEC.md`
5. `02_CANONICAL_DATA_MODEL_AND_RLS_SPEC.md`
6. `03_FINANCIAL_PAYMENT_API_EVENT_SECURITY_SPEC.md`
7. `04_UI_UX_PRODUCT_IMPLEMENTATION_SPEC.md`
8. `05_DELIVERY_PLAN_TESTS_AND_ACCEPTANCE_GATES.md`
9. `06_CODEX_CLAUDE_MASTER_EXECUTION_PROMPT.md`
10. `09_OFFICIAL_SOURCE_AND_VERIFICATION_NOTES.md`
11. `10_REMAINING_FOUNDER_DECISIONS_QUESTIONNAIRE.md`

Key approved direction:

- One global rental core
- North American early commercial profiles: United States, Canada, Mexico
- Virginia first validation jurisdiction
- Stripe Connect direct charges to eligible operator-controlled accounts
- No pooled rent custody
- Multi-country organizations through operating entities and single-currency accounting books
- Ghana, Nigeria, and Singapore as preparation markets
- Public rental/vendor marketplaces remain post-launch

The remaining decisions are listed explicitly in `07_FOUNDER_DECISION_REGISTER.md`.

## Compliance-integrated additions

- `09_PRIVACY_SECURITY_COMPLIANCE_AND_LEGAL_DOCUMENT_SPEC.md` — platform privacy, security, payments, communications, accessibility, subscription, AI, and country compliance architecture.
- `11_COUNSEL_AND_COMPLIANCE_LAUNCH_CHECKLIST.md` — evidence-based legal and production launch gates for the United States, Canada, and Mexico.
