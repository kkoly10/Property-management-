# Apartment Rental Platform — Senior Engineering Edition

**Version:** 2.0  
**Date:** July 18, 2026  
**Status:** Implementation specification with explicit decision gates  
**Intended users:** Founder, staff/principal engineers, product design, security reviewers, Codex, Claude Code

## What this package is

This package replaces the earlier architecture and UI/UX blueprints with a tighter, implementation-oriented specification. It separates decisions that are:

1. **Fixed** — coding agents must not reinterpret them.
2. **Configurable** — implemented as data or policy, not hardcoded conditionals.
3. **Deferred** — structurally anticipated but not built for launch.
4. **Externally blocked** — require founder, legal, accounting, or payment-provider approval.

It is designed to prevent a coding agent from inventing the product model, financial behavior, permissions, or user experience while implementing.

## Document order

1. `01_PRODUCT_AND_SYSTEM_ARCHITECTURE_SPEC.md`
2. `02_CANONICAL_DATA_MODEL_AND_RLS_SPEC.md`
3. `03_FINANCIAL_PAYMENT_API_EVENT_SECURITY_SPEC.md`
4. `04_UI_UX_PRODUCT_IMPLEMENTATION_SPEC.md`
5. `05_DELIVERY_PLAN_TESTS_AND_ACCEPTANCE_GATES.md`
6. `06_CODEX_CLAUDE_MASTER_EXECUTION_PROMPT.md`
7. `07_FOUNDER_DECISION_REGISTER.md`

## Required usage

The coding agent must read all seven documents before modifying code. The agent must not start implementation until it has:

- reconciled the repository against the target architecture;
- completed the open-decision register with the founder;
- identified any legal or payment questions that block implementation;
- produced a migration and rollback plan;
- produced a screen-level gap map;
- verified the current official documentation for Next.js, Supabase, and the selected payment provider.

## Product in one sentence

> A multi-tenant rental-property operating system sold to operators, with a purpose-built resident experience, transparent owner portal, and private vendor workflow; public marketplaces and financial products remain post-launch.

## Launch boundary

### Included

- Operator OS
- Resident experience
- Owner portal
- Private vendor management
- Shareable vacancy pages and direct application capture
- Leasing, rent, ledger, payments, maintenance, inspections, communications, reports, and support operations

### Excluded

- Public aggregated rental marketplace
- Open vendor marketplace
- Lending, underwriting, rent guarantees, deposit replacement, or insurance risk
- Cross-operator renter reputation
- Institutional-grade investment accounting
- Enterprise revenue-management algorithms

## Quality claim

This package is intended to be **senior-engineering-grade and implementation-ready once Gate 0 decisions are resolved**. It does not claim that an unbuilt system is production-proven. Production approval still requires implementation, verification, operator validation, security review, legal review, and operational readiness testing.
