# Founder Decision Register — Global Platform / North American Early Launch

**Version:** 2.0  
**Decision date:** 2026-07-18  
**Purpose:** Separate approved founder direction from remaining product choices and external legal, tax, accounting, privacy, and payment determinations. Coding must not silently resolve an unresolved item.

## A. Approved product and launch decisions

| ID | Decision | Status | Implementation consequence |
|---|---|---:|---|
| PD-001 | Operator is the paying customer. | Approved | SaaS subscription belongs to the organization. |
| PD-002 | Residents, owners, and private vendors participate through operator-controlled relationships. | Approved | No consumer network is required for launch. |
| PD-003 | Launch includes Operator OS, Resident Experience, Owner Portal, Private Vendor Management, and Shareable Vacancy Tools. | Approved | These are first-class launch surfaces. |
| PD-004 | Public rental and open vendor marketplaces are post-launch. | Approved | No marketplace liquidity, public ranking, cross-operator ratings, or commissions at launch. |
| PD-005 | Architecture begins as a modular monolith with PostgreSQL as canonical truth and ledger-derived balances. | Approved | No speculative microservices or provider-owned financial truth. |
| PD-006 | Build one global platform with regional preset families, versioned country operating profiles, and subnational jurisdiction packages. | Approved | Continents provide defaults only; properties resolve to country and state/province/local law. |
| PD-007 | Early commercial launch countries are the United States, Canada, and Mexico. | Approved | Build all three country profiles as the North American launch family. |
| PD-008 | Virginia is the first United States product-validation jurisdiction. | Approved | Complete Virginia launch gate first; other states activate independently. |
| PD-009 | Ghana, Nigeria, and Singapore are preparation markets during North American launch. | Approved | Research, partnerships, and profile scaffolding may proceed; production stays disabled until activation. |
| PD-010 | One organization may operate across countries through operating entities and single-currency accounting books. | Approved | Remove one-country/one-currency organization assumptions. |
| PD-011 | Property location and confirmed jurisdiction control legal/payment behavior; device/IP location is advisory only. | Approved | Onboarding must request business, property, currency, and merchant context. |
| PD-012 | Use provider-neutral payment orchestration. | Approved | Country adapters implement one canonical internal payment model. |
| PD-013 | In Stripe-supported launch profiles, eligible small landlords/operators use a full-Dashboard/Standard-equivalent connected account and direct charges. | Approved | Rent charge belongs to operator connected account; objects are queried in connected-account context. |
| PD-014 | Resident rent settles directly to the operator's approved account; platform does not pool or custody rent. | Approved | Platform records/allocates/reconciles money but does not hold it. |
| PD-015 | Platform SaaS billing remains separate from resident rent. | Approved | Distinct billing/customer/ledger flows. |
| PD-016 | Security deposits are separate from rent and disabled for ordinary online collection until the jurisdiction custody model is approved. | Approved | Deposit payment eligibility is obligation- and jurisdiction-specific. |
| PD-017 | North American initial payment targets are US ACH/cards, Canadian ACSS PAD/cards, and Mexican SPEI bank transfer/cards. | Approved architecture | Runtime activation depends on provider capability and legal/product approval. |
| PD-018 | English and Spanish are required for the US/Canada/Mexico product; French is required before Quebec activation. | Approved baseline | All launch UX and documents are localization-ready; Quebec remains blocked without French/legal pack. |
| PD-019 | Resident experience launches as responsive PWA; native apps remain post-validation. | Approved | One mobile-first web implementation. |
| PD-020 | AI cannot autonomously execute legal or financial actions. | Approved | AI may summarize/propose only. |

## B. Approved payment-account configuration

The intended Stripe account behavior is:

- Stripe-hosted onboarding and KYC;
- connected account has full Stripe Dashboard access;
- direct charges for resident payments;
- connected account is payment-fee payer where supported;
- connected account handles its direct-charge refunds, disputes, and negative balance responsibilities under provider terms;
- platform may receive a disclosed application fee only after FD-010 and country tax/legal review;
- operator controls payout destination;
- platform synchronizes payment, allocation, settlement, dispute, and reconciliation state.

The implementation must model these responsibilities rather than depending only on the legacy word `Standard`, because provider account APIs and terminology may evolve.

## C. Remaining founder decisions

| ID | Question | Why it matters | Recommended default | Blocking scope |
|---|---|---|---|---|
| FD-001 | Who is the primary launch go-to-market segment: small landlords, professional property managers, or a dual path? | Changes onboarding, pricing, support, copy, and sales motion. | Dual product support; market first to landlords/managers with roughly 5–250 units. | GTM, onboarding, pricing |
| FD-002 | What is the SaaS pricing model and trial? | Drives entitlements, billing, limits, and packaging. | Base subscription plus active-unit meter; 14-day trial with no production money movement until verification. | SaaS billing |
| FD-003 | Will the platform charge an application/transaction fee on resident rent, and who pays it? | Affects Stripe application fees, disclosures, taxes, resident UX, and unit economics. | Operator-paid platform fee or subscription-first launch; do not default to resident surcharge. | Pricing, tax, checkout |
| FD-004 | Is the Owner Portal included in all paid plans or professional plans only? | Controls entitlements and sales positioning. | Include for professional tier and above; offer limited owner visibility in entry tier. | Entitlements |
| FD-005 | What is the first Canadian province rollout? | Canada tenancy, deposits, documents, notices, and privacy vary by province. | Alberta first, Ontario next; Quebec only after French and Quebec review. | Canadian launch |
| FD-006 | What is the first Mexican state rollout? | Mexico requires national behavior plus state tenancy documents/rules. | Select one launch state based on pilot partners; do not market nationwide legal automation before this answer. | Mexican launch |
| FD-007 | After Virginia, is the US rollout state-by-state or a limited national SaaS mode without legal document automation? | Determines marketing claims and product restrictions. | State-by-state full packs; allow unsupported-state waitlist/read-only demo only. | US expansion |
| FD-008 | Will operators be permitted to record cash and external bank-transfer payments? | Important globally but creates fraud and reconciliation risk. | Yes, with permission, receipt, evidence/reason, audit, and optional approval threshold. | Finance UX |
| FD-009 | Are shareable vacancy pages platform-branded, operator-branded, or tiered? | Affects design system, domains, and pricing. | Platform branding on entry; operator branding on professional; custom domain later. | Public pages |
| FD-010 | Are card convenience fees/surcharges ever passed to residents? | Highly jurisdiction- and network-sensitive. | No resident surcharge at first launch; revisit country by country. | Checkout/legal |
| FD-011 | Which operator support model launches: self-serve only, assisted onboarding, or managed migration? | Data imports and setup are major adoption risks. | Assisted onboarding for initial cohorts with self-serve product underneath. | Operations/GTM |
| FD-012 | What are the activation goals/order after North America among Ghana, Nigeria, and Singapore? | Guides research staffing and provider/legal work. | Ghana first, Nigeria second, Singapore third unless partnerships alter the score. | Expansion roadmap |

## D. External professional determinations required for every activated jurisdiction

These cannot be approved by a coding agent. Each country and subnational pack receives its own evidence and reviewer record.

| ID | Required determination | Reviewer | Blocking consequence |
|---|---|---|---|
| EX-001 | Confirm merchant-of-record and contractual roles for resident rent, application fees, and SaaS fees under the approved direct-charge model. | Payments/legal/tax | Blocks production checkout disclosures and contracts. |
| EX-002 | Confirm the platform has no custody/control of client funds and identify any residual payment, money-transmission, trust, or agency obligations. | Payments/legal | Blocks flow-of-funds approval. |
| EX-003 | Define security-deposit collection, destination account, segregation/trust, interest, notices, deductions, and return requirements. | Property counsel/accountant | Online deposit collection remains disabled. |
| EX-004 | Approve lease, renewal, notice, entry, termination, move-out, and deposit-deduction templates. | Local property counsel | Blocks production document automation. |
| EX-005 | Approve electronic-signature method, consent, evidence, and retention. | Counsel/e-sign provider | Blocks final signature workflow. |
| EX-006 | Approve privacy, retention, deletion, access, cross-border processing, and data-residency policy. | Privacy counsel/security | Blocks production personal-data processing. |
| EX-007 | Approve late fees, service charges, rent-payment method restrictions, card surcharges, and resident disclosures. | Property/payments counsel | Blocks configurable fee/payment policy. |
| EX-008 | Determine SaaS, application-fee, sales tax/GST-HST/VAT, rent, and vendor-service tax/invoice obligations. | Tax counsel/accountant | Blocks compliant billing/invoicing. |
| EX-009 | Determine whether operator/property-management licensing or registration prompts are required. | Local property counsel | Blocks operator activation where licensing applies. |
| EX-010 | Approve owner-remittance accounting and whether automated owner disbursement is permitted. | Banking/payments/legal | Automated payout remains disabled. |
| EX-011 | Approve tenant application/screening, adverse-action, identity, and consent rules if screening is enabled. | Housing/privacy counsel | Screening stays disabled or limited. |
| EX-012 | Mexico: approve RFC/CFDI integration, required invoice fields, cancellation/replacement process, and provider. | Mexican tax counsel/accountant | Tax receipt automation blocked. |
| EX-013 | Canada: approve province-specific PAD presentation, tenancy payment restrictions, deposit treatment, privacy regime, and tax registration. | Canadian payments/property/privacy/tax reviewers | Province launch blocked. |
| EX-014 | United States: approve state-specific leases/notices/deposits/fees and platform nexus/tax posture. | US state counsel/tax reviewer | State full-launch pack blocked. |

## E. Deferred decisions

- Public marketplace launch geography and liquidity threshold
- Public vendor verification, bidding, and rating model
- Rental guarantees, insurance, deposit replacement, lending, or underwriting
- Cross-border owner payouts and foreign exchange
- Cross-operator renter identity or reputation
- Native applications
- Automated owner payouts
- Institutional portfolio accounting and consolidation
- Production activation of Ghana, Nigeria, Singapore, or another country before their gates pass

## F. Decision protocol

1. Every decision change receives a dated record and owner.
2. Financial, permission, payment-account, country-profile, or legal changes require an ADR.
3. Historical leases, documents, payments, and ledgers retain the versions active when created.
4. Coding agents may propose options but cannot approve external determinations.
5. “Country supported” is reserved for an active country plus exact subnational package; localization-only or research profiles must be labeled accurately.
