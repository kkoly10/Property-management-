# Remaining Founder Decisions Questionnaire

The global architecture, North American early launch, direct-to-operator Stripe Connect payment posture, and future preparation markets are approved. Answer the following choices to close the remaining founder-controlled decisions.

## 1. Primary launch customer

Choose one:

- [ ] Small landlords, primarily 1–25 units
- [ ] Growing landlords/property managers, primarily 5–250 units
- [ ] Professional property managers, primarily 20–500 units
- [ ] Dual path with separate onboarding and packaging

**Senior recommendation:** Support both, but market first to growing landlords and property managers with approximately 5–250 units. They have real operational pain without enterprise procurement complexity.

## 2. SaaS pricing model and trial

Choose one:

- [ ] Flat portfolio tiers
- [ ] Base subscription plus active-unit fee
- [ ] Per-unit only
- [ ] Free entry plan plus paid tiers

Trial:

- [ ] 7 days
- [ ] 14 days
- [ ] 30 days
- [ ] No trial; assisted pilot

**Senior recommendation:** Base subscription plus active-unit fee, with a 14-day product trial. Production payment collection activates only after merchant verification.

## 3. Rent-payment monetization

Choose one:

- [ ] Subscription revenue only at launch
- [ ] Operator-paid application fee on each rent payment
- [ ] Resident-paid convenience fee where legally allowed
- [ ] Hybrid by plan/country

**Senior recommendation:** Subscription-first. Add a disclosed operator-paid application fee only after tax, margin, and country disclosure review. Do not launch with resident surcharges.

## 4. Owner Portal packaging

Choose one:

- [ ] Included in every paid plan
- [ ] Limited in entry plan; full portal in professional plans
- [ ] Premium add-on only

**Senior recommendation:** Limited owner visibility in entry tier and complete owner statements/approvals in professional tier and above.

## 5. Canada activation order

Choose one:

- [ ] Alberta first, Ontario second
- [ ] Ontario first, Alberta second
- [ ] Another province first: __________
- [ ] Quebec included in the first Canadian release

**Senior recommendation:** Alberta first, Ontario second. Quebec only after French localization and Quebec-specific legal/privacy review.

## 6. Mexico initial state

Select the first state based on pilot access and legal review:

- [ ] Mexico City
- [ ] State of Mexico
- [ ] Jalisco
- [ ] Nuevo León
- [ ] Quintana Roo
- [ ] Another: __________

**Senior recommendation:** Choose the state where you can secure the strongest operator pilot and local counsel. Do not claim nationwide legal automation before state packs exist.

## 7. United States expansion after Virginia

Choose one:

- [ ] Activate full functionality state by state
- [ ] Offer nationwide operations but disable legal-document automation in unsupported states
- [ ] Market only in approved states

**Senior recommendation:** Market full functionality only in approved states. Unsupported states may use a waitlist/demo mode, not production legal workflows.

## 8. Manual and cash payments

Choose one:

- [ ] Allow both cash and external bank-transfer recording
- [ ] Allow external bank transfer only
- [ ] Disable manual payment recording

**Senior recommendation:** Allow both with permission, evidence or reason, generated receipt, reconciliation status, audit trail, and optional secondary approval above a threshold.

## 9. Vacancy-page branding

Choose one:

- [ ] Platform branding for all plans
- [ ] Operator branding for all paid plans
- [ ] Tiered branding

**Senior recommendation:** Platform branding in entry plan, operator branding in professional plan, and custom domains after MVP validation.

## 10. Card convenience fees

Choose one:

- [ ] Platform/operator absorbs all card fees
- [ ] Resident may pay a fee where legal
- [ ] Cards are optional and bank debit/transfer is promoted

**Senior recommendation:** No resident surcharge at first launch. Promote lower-cost bank rails and revisit fees jurisdiction by jurisdiction.

## 11. Customer onboarding and migration

Choose one:

- [ ] Fully self-serve
- [ ] Assisted onboarding for early customers
- [ ] Paid managed migration
- [ ] Assisted launch cohort, then self-serve

**Senior recommendation:** Assisted launch cohort with reusable self-serve import tools underneath. Add paid managed migration after patterns are known.

## 12. Expansion priority after North America

Rank:

- [ ] Ghana
- [ ] Nigeria
- [ ] Singapore

**Senior recommendation:** Ghana first, Nigeria second, Singapore third, unless an operator partnership or legal/payment advantage materially changes the score.

## Decisions that engineering cannot close

The following require qualified reviewers for every activated jurisdiction:

- merchant-of-record and contractual payment roles;
- confirmation that the platform does not have custody/control of rent;
- security-deposit custody, segregation, interest, deductions, and returns;
- leases, notices, late fees, service charges, and rent-payment restrictions;
- electronic-signature validity and evidence;
- privacy, retention, cross-border processing, and data residency;
- SaaS/application-fee sales tax, GST/HST, VAT, and invoicing;
- operator/property-management licensing boundaries;
- tenant-screening and adverse-action obligations if enabled;
- Mexico RFC/CFDI integration;
- Canadian province-specific PAD and tenancy requirements;
- U.S. state-specific tenancy and platform tax/nexus obligations;
- automated owner payout permission, which remains disabled.
